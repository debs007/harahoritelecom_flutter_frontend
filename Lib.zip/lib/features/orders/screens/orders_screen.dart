import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/widgets/common_widgets.dart';
import '../../../core/services/api_service.dart';
import '../../../core/constants/api_constants.dart';

// autoDispose = re-fetches every time the screen is opened
final ordersProvider = FutureProvider.autoDispose<List<dynamic>>((ref) async {
  final res  = await ApiService.get(ApiConstants.orders);
  final body = res.data;
  if (body is List)              return body;
  if (body['data'] is List)      return body['data'] as List;
  return [];
});

class OrdersScreen extends ConsumerWidget {
  const OrdersScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ordersAsync = ref.watch(ordersProvider);

    return PopScope(
      canPop: false,
      onPopInvoked: (_) => context.go('/'),
      child: Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface, elevation: 0,
        title: const Text('My Orders', style: TextStyle(fontWeight: FontWeight.w900, color: AppColors.textPrimary)),
      ),
      body: ordersAsync.when(
        loading: () => const Center(child: CircularProgressIndicator(color: AppColors.primary)),
        error: (e, _) => RefreshIndicator(
          color: AppColors.primary,
          onRefresh: () => ref.refresh(ordersProvider.future),
          child: ListView(children: [
            SizedBox(height: MediaQuery.of(context).size.height * 0.4,
              child: Center(child: Text('Error: $e'))),
          ]),
        ),
        data: (orders) => RefreshIndicator(
          color: AppColors.primary,
          onRefresh: () => ref.refresh(ordersProvider.future),
          child: orders.isEmpty
              ? ListView(children: const [
                  SizedBox(height: 200),
                  EmptyState(emoji: '📦', title: 'No orders yet',
                      subtitle: 'Start shopping and your orders will appear here'),
                ])
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: orders.length,
                  itemBuilder: (_, i) => _OrderCard(order: orders[i]),
                ),
        ),
      ),
    ),
    );
  }
}

class _OrderCard extends StatelessWidget {
  final dynamic order;
  const _OrderCard({required this.order});

  @override
  Widget build(BuildContext context) {
    final status   = order['status'] ?? 'pending';
    final color    = _statusColor(status);
    final items    = order['items'] as List? ?? [];

    return GestureDetector(
      onTap: () => context.push('/orders/${order['order_number']}'),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(color: AppColors.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.border)),
        child: Column(children: [
          // Header
          Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(color: AppColors.borderLight,
                borderRadius: const BorderRadius.vertical(top: Radius.circular(16))),
            child: Row(children: [
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(order['order_number'], style: const TextStyle(
                    fontWeight: FontWeight.w800, fontSize: 13)),
                Text(_formatDate(order['created_at'] ?? ''),
                    style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
              ]),
              const Spacer(),
              Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(color: color.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(20)),
                child: Text(order['status_label'] ?? status,
                    style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: color))),
            ])),

          // Items preview — thumbnail + name + variant/color
          Padding(padding: const EdgeInsets.all(12), child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ...items.take(3).map((item) {
                final variantDetails = item['variant_details'] as String?;
                final parts = variantDetails?.split(' | ')
                    .where((p) => p.trim().isNotEmpty).toList() ?? [];
                return Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    AppNetworkImage(
                        url: item['thumbnail'],
                        width: 48, height: 48,
                        borderRadius: BorderRadius.circular(8),
                        fit: BoxFit.contain),
                    const SizedBox(width: 8),
                    Expanded(child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(item['product_name'] ?? '',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                fontSize: 12, fontWeight: FontWeight.w700,
                                color: AppColors.textPrimary)),
                        if (parts.isNotEmpty)
                          Wrap(spacing: 4, runSpacing: 2,
                            children: parts.map((p) {
                              final isColor   = p.startsWith('Color:');
                              final isRam     = p.startsWith('RAM:');
                              final isStorage = p.startsWith('Storage:');
                              return Container(
                                margin: const EdgeInsets.only(top: 2),
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: isColor
                                      ? AppColors.primaryLight
                                      : isRam
                                          ? const Color(0xFFDEF7EC)
                                          : isStorage
                                              ? const Color(0xFFFEF3C7)
                                              : AppColors.borderLight,
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(p,
                                    style: TextStyle(
                                        fontSize: 10, fontWeight: FontWeight.w700,
                                        color: isColor
                                            ? AppColors.primary
                                            : isRam
                                                ? AppColors.success
                                                : isStorage
                                                    ? const Color(0xFF92400E)
                                                    : AppColors.textSecondary)),
                              );
                            }).toList()),
                        Text('Qty: ${item['quantity']}',
                            style: const TextStyle(
                                fontSize: 11, color: AppColors.textSecondary)),
                      ],
                    )),
                  ]),
                );
              }),
              if (items.length > 3)
                Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Text('+${items.length - 3} more item${items.length - 3 > 1 ? 's' : ''}',
                      style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                ),
              const SizedBox(height: 4),
              Row(children: [
                const Text('Order Total:',
                    style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                const SizedBox(width: 6),
                Text('₹${_fmt((order['total'] as num).toDouble())}',
                    style: const TextStyle(
                        fontWeight: FontWeight.w900, fontSize: 16, color: AppColors.primary)),
              ]),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: AppOutlinedButton(label: 'View Details', height: 36,
                  onTap: () => context.push('/orders/${order['order_number']}'))),
                if (status != 'delivered' && status != 'cancelled' && status != 'refunded') ...[
                  const SizedBox(width: 8),
                  Expanded(child: GradientButton(label: 'Track Order', height: 36,
                    onTap: () => context.push('/orders/${order['order_number']}'))),
                ],
              ]),
            ],
          )),
        ]),
      ),
    );
  }

  Color _statusColor(String status) {
    return switch (status) {
      'delivered' => AppColors.success,
      'cancelled' => AppColors.error,
      'shipped' || 'out_for_delivery' => AppColors.primary,
      'confirmed' => AppColors.info,
      _ => AppColors.warning,
    };
  }

  String _fmt(double v) => v.toInt().toString().replaceAllMapped(
      RegExp(r'(\d)(?=(\d{3})+(?!\d))'), (m) => '${m[1]},');

  String _formatDate(String iso) {
    if (iso.isEmpty) return '';
    try {
      final dt = DateTime.parse(iso);
      const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      return '${dt.day} ${months[dt.month - 1]} ${dt.year}';
    } catch (_) { return iso; }
  }
}
